import pandas as pd
import glob
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.random_projection import SparseRandomProjection
from sklearn.metrics.pairwise import cosine_similarity

df = pd.concat(
    [pd.read_csv(f) for f in glob.glob("notices/*.csv")],
    ignore_index=True
).fillna("")

pairs = pd.read_csv("labelled_pairs.csv")

texts = df["title"] + " " + df["body"]

vectorizer = TfidfVectorizer(
    stop_words="english",
    ngram_range=(1, 2)
)

X = vectorizer.fit_transform(texts)

index = pd.Series(range(len(df)), index=df["notice_id"])

a = [index[x] for x in pairs["notice_id_a"]]
b = [index[x] for x in pairs["notice_id_b"]]

# Exact similarity
exact = np.array([
    cosine_similarity(X[i], X[j])[0, 0]
    for i, j in zip(a, b)
])

# 256-dimensional representation
projector = SparseRandomProjection(
    n_components=256,
    random_state=42
)

R = projector.fit_transform(X)

estimated = np.array([
    cosine_similarity(R[i], R[j])[0, 0]
    for i, j in zip(a, b)
])

pairs["exact"] = exact
pairs["estimated"] = estimated
pairs["error"] = abs(exact - estimated)

print("Overall MAE:", round(pairs["error"].mean(), 4))

print("\nError by label:")
print(
    pairs.groupby("label")["error"]
    .agg(["count", "mean", "max"])
)

print("\nLargest errors:")
print(
    pairs.nlargest(10, "error")[
        ["notice_id_a", "notice_id_b", "label",
         "exact", "estimated", "error"]
    ].to_string(index=False)
)

pairs.to_csv("error_report.csv", index=False)

print("\nSaved: error_report.csv")
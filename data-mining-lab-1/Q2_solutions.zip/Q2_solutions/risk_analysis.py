import pandas as pd
import numpy as np

pairs = pd.read_csv("similarity_results.csv")

# Test different business risk ratios:
# false merge : false split
ratios = [2, 5, 10, 20, 50, 100]

best_results = []

for ratio in ratios:

    best_cost = float("inf")
    best_threshold = None
    best_fm = 0
    best_fs = 0

    for threshold in np.arange(0.00, 1.001, 0.001):

        predicted_same = pairs["similarity"] >= threshold

        false_merge = (
            (predicted_same) &
            (pairs["label"] == "different")
        ).sum()

        false_split = (
            (~predicted_same) &
            (pairs["label"] == "same")
        ).sum()

        cost = ratio * false_merge + false_split

        if cost < best_cost:
            best_cost = cost
            best_threshold = threshold
            best_fm = false_merge
            best_fs = false_split

    best_results.append([
        ratio,
        round(best_threshold, 3),
        best_fm,
        best_fs,
        best_cost
    ])

result = pd.DataFrame(
    best_results,
    columns=[
        "False_merge_cost_ratio",
        "Threshold",
        "False_merges",
        "False_splits",
        "Total_cost"
    ]
)

print(result.to_string(index=False))

result.to_csv("risk_analysis.csv", index=False)

print("\nSaved: risk_analysis.csv")
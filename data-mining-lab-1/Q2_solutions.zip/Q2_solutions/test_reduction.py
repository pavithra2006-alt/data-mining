import pandas as pd
import glob
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.random_projection import SparseRandomProjection
from sklearn.metrics.pairwise import cosine_similarity

# Load notices
df = pd.concat(
    [pd.read_csv(f) for f in glob.glob("notices/*.csv")],
    ignore_index=True
).fillna("")

# Load labelled pairs
pairs = pd.read_csv("labelled_pairs.csv")

# Combine title + body
texts = df["title"] + " " + df["body"]

# TF-IDF with unigrams + bigrams
vectorizer = TfidfVectorizer(
    stop_words="english",
    ngram_range=(1, 2)
)

X = vectorizer.fit_transform(texts)

# Notice ID -> row number
index = pd.Series(range(len(df)), index=df["notice_id"])

a = [index[x] for x in pairs["notice_id_a"]]
b = [index[x] for x in pairs["notice_id_b"]]

# Exact cosine similarity
exact = np.array([
    cosine_similarity(X[i], X[j])[0, 0]
    for i, j in zip(a, b)
])

print("Original dimensions:", X.shape[1])
print()
print("Reduced size     MAE")

for size in [64, 128, 256, 512]:
    projector = SparseRandomProjection(
        n_components=size,
        random_state=42
    )

    R = projector.fit_transform(X)

    estimated = np.array([
        cosine_similarity(R[i], R[j])[0, 0]
        for i, j in zip(a, b)
    ])

    mae = np.mean(np.abs(exact - estimated))

    print(f"{size:12d}     {mae:.4f}")
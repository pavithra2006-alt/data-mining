import pandas as pd

pairs = pd.read_csv("error_report.csv")
candidates = pd.read_csv("candidate_pairs.csv")

candidate_set = set(
    zip(candidates["notice_id_a"], candidates["notice_id_b"])
)

def is_candidate(a, b):
    return (a, b) in candidate_set or (b, a) in candidate_set

pairs["retrieved"] = [
    is_candidate(a, b)
    for a, b in zip(pairs["notice_id_a"], pairs["notice_id_b"])
]

threshold = 0.459

pairs["predicted_same"] = pairs["estimated"] >= threshold

pairs["decision_error"] = (
    (pairs["label"] == "same") != pairs["predicted_same"]
)

print("=== RETRIEVAL FAILURES ===")
print(
    pairs[(pairs["label"] == "same") & (~pairs["retrieved"])][
        ["notice_id_a", "notice_id_b", "label"]
    ].to_string(index=False)
)

print("\nSame pairs missed by retrieval:",
      ((pairs["label"] == "same") & (~pairs["retrieved"])).sum())

print("\n=== DECISION FAILURES ===")
print(
    pairs[pairs["decision_error"]][
        ["notice_id_a", "notice_id_b", "label",
         "exact", "estimated", "error"]
    ].to_string(index=False)
)

print("\nTotal decision errors:",
      pairs["decision_error"].sum())

print("\n=== DANGEROUS DIFFERENT PAIRS ===")
print(
    pairs[pairs["label"] == "different"]
    .nlargest(10, "estimated")[
        ["notice_id_a", "notice_id_b",
         "exact", "estimated", "retrieved"]
    ].to_string(index=False)
)

print("\n=== DANGEROUS SAME PAIRS ===")
print(
    pairs[pairs["label"] == "same"]
    .nsmallest(10, "estimated")[
        ["notice_id_a", "notice_id_b",
         "exact", "estimated", "retrieved"]
    ].to_string(index=False)
)
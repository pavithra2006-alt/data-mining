import pandas as pd
import glob
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.random_projection import SparseRandomProjection
from sklearn.neighbors import NearestNeighbors

# Load notices
df = pd.concat(
    [pd.read_csv(f) for f in glob.glob("notices/*.csv")],
    ignore_index=True
).fillna("")

texts = df["title"] + " " + df["body"]

# TF-IDF representation
vectorizer = TfidfVectorizer(
    stop_words="english",
    ngram_range=(1, 2)
)

X = vectorizer.fit_transform(texts)

# Reduce to 256 dimensions
projector = SparseRandomProjection(
    n_components=256,
    random_state=42
)

R = projector.fit_transform(X)

# Candidate retrieval
K = 20

nn = NearestNeighbors(
    n_neighbors=K + 1,
    metric="cosine"
)

nn.fit(R)

distances, indices = nn.kneighbors(R)

candidate_pairs = set()

for i in range(len(df)):
    for j in indices[i][1:]:
        a = min(i, j)
        b = max(i, j)
        candidate_pairs.add((a, b))

all_pairs = len(df) * (len(df) - 1) // 2
candidate_count = len(candidate_pairs)

print("Total notices:", len(df))
print("All-pairs comparisons:", all_pairs)
print("Candidate pairs:", candidate_count)
print("Reduction:", round(1 - candidate_count / all_pairs, 6))
print("Candidate pairs per notice:", round(
    2 * candidate_count / len(df), 2
))

# Check labelled-pair retrieval
pairs = pd.read_csv("labelled_pairs.csv")

index = pd.Series(range(len(df)), index=df["notice_id"])

found = 0

for _, row in pairs.iterrows():
    a = index[row["notice_id_a"]]
    b = index[row["notice_id_b"]]

    if (min(a, b), max(a, b)) in candidate_pairs:
        found += 1

recall = found / len(pairs)

print("Labelled pairs retrieved:", found, "/", len(pairs))
print("Candidate recall:", round(recall, 4))

# Recall separately for same/different
for label in ["same", "different"]:
    subset = pairs[pairs["label"] == label]
    count = 0

    for _, row in subset.iterrows():
        a = index[row["notice_id_a"]]
        b = index[row["notice_id_b"]]

        if (min(a, b), max(a, b)) in candidate_pairs:
            count += 1

    print(
        label,
        "retrieval:",
        count,
        "/",
        len(subset),
        "=",
        round(count / len(subset), 4)
    )

pd.DataFrame(
    [(df.iloc[a]["notice_id"], df.iloc[b]["notice_id"])
     for a, b in candidate_pairs],
    columns=["notice_id_a", "notice_id_b"]
).to_csv("candidate_pairs.csv", index=False)

print("Saved: candidate_pairs.csv")